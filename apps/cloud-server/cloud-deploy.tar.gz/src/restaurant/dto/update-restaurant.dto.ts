export class UpdateRestaurantDto {
    name?: string;
    phone?: string;
    address?: string;
    subscriptionEndDate?: Date;
    isActive?: boolean;
}
